    let num = 1;
   setInterval(function () {
       num ++;
       console.log(num);
	   document.getElementById("ReSendRequestWeekCourseBtn").click();

   }, 60000000);
